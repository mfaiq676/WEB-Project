    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5><i class="fas fa-car me-2 text-accent"></i>DriveEase</h5>
                    <p style="font-size:0.9rem;line-height:1.8;">Your trusted car rental service. Premium vehicles, affordable rates, and exceptional service across Pakistan.</p>
                    <div class="d-flex gap-3 mt-2">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-sm-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled" style="font-size:0.9rem;line-height:2.2;">
                        <li><a href="<?= SITE_URL ?>">Home</a></li>
                        <li><a href="<?= SITE_URL ?>/user/browse_cars.php">Browse Cars</a></li>
                        <li><a href="<?= SITE_URL ?>/auth/login.php">Login</a></li>
                        <li><a href="<?= SITE_URL ?>/auth/register.php">Register</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 mb-4">
                    <h5>Car Categories</h5>
                    <ul class="list-unstyled" style="font-size:0.9rem;line-height:2.2;">
                        <li><a href="#">Economy Cars</a></li>
                        <li><a href="#">Sedans</a></li>
                        <li><a href="#">SUVs</a></li>
                        <li><a href="#">Luxury Cars</a></li>
                        <li><a href="#">Vans & Minibuses</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled" style="font-size:0.9rem;line-height:2.4;">
                        <li><i class="fas fa-map-marker-alt me-2 text-accent"></i>Taxila, Punjab, Pakistan</li>
                        <li><i class="fas fa-phone me-2 text-accent"></i>+92-300-1234567</li>
                        <li><i class="fas fa-envelope me-2 text-accent"></i>info@driveease.pk</li>
                        <li><i class="fas fa-clock me-2 text-accent"></i>Mon–Sat: 8AM – 8PM</li>
                    </ul>
                </div>
            </div>
            <div class="footer-divider"></div>
            <div class="row align-items-center">
                <div class="col-md-6" style="font-size:0.85rem;">
                    &copy; <?= date('Y') ?> DriveEase Car Rentals. All rights reserved.
                </div>
                <div class="col-md-6 text-md-end" style="font-size:0.85rem;">
                    CS-309 Project | HITEC University Taxila
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Custom JS -->
    <script src="<?= SITE_URL ?>/js/main.js"></script>
    <script>AOS.init({ duration: 700, once: true, offset: 50 });</script>
</body>
</html>
