-- ============================================
-- Car Rental Management System - Database
-- CS-309 Web Design and Development
-- HITEC University Taxila
-- ============================================

CREATE DATABASE IF NOT EXISTS car_rental_db;
USE car_rental_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('user', 'admin') DEFAULT 'user',
    profile_pic VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cars Table
CREATE TABLE IF NOT EXISTS cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year YEAR NOT NULL,
    color VARCHAR(50),
    license_plate VARCHAR(20) UNIQUE NOT NULL,
    category ENUM('Economy', 'Sedan', 'SUV', 'Luxury', 'Van') DEFAULT 'Sedan',
    transmission ENUM('Manual', 'Automatic') DEFAULT 'Automatic',
    fuel_type ENUM('Petrol', 'Diesel', 'Electric', 'Hybrid') DEFAULT 'Petrol',
    seats INT DEFAULT 5,
    price_per_day DECIMAL(10,2) NOT NULL,
    status ENUM('Available', 'Rented', 'Maintenance') DEFAULT 'Available',
    image VARCHAR(255) DEFAULT 'default_car.png',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    car_id INT NOT NULL,
    pickup_date DATE NOT NULL,
    return_date DATE NOT NULL,
    pickup_location VARCHAR(200),
    total_days INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Ongoing', 'Completed', 'Cancelled') DEFAULT 'Pending',
    payment_status ENUM('Unpaid', 'Paid') DEFAULT 'Unpaid',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

-- Contact Messages Table
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Sample Data
-- ============================================

-- Admin User (password: admin123)
INSERT INTO users (full_name, email, password, phone, role) VALUES
('Admin User', 'admin@carrental.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '03001234567', 'admin');

-- Regular User (password: user123)
INSERT INTO users (full_name, email, password, phone, role) VALUES
('Ali Hassan', 'ali@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '03111234567', 'user');

-- Sample Cars
INSERT INTO cars (brand, model, year, color, license_plate, category, transmission, fuel_type, seats, price_per_day, status, description) VALUES
('Toyota', 'Corolla', 2023, 'White', 'ABC-123', 'Sedan', 'Automatic', 'Petrol', 5, 5000.00, 'Available', 'Comfortable sedan with modern features and fuel efficiency.'),
('Honda', 'Civic', 2022, 'Silver', 'XYZ-456', 'Sedan', 'Automatic', 'Petrol', 5, 5500.00, 'Available', 'Sporty and reliable sedan perfect for city drives.'),
('Toyota', 'Fortuner', 2023, 'Black', 'DEF-789', 'SUV', 'Automatic', 'Diesel', 7, 12000.00, 'Available', 'Powerful SUV for family trips and rough terrain.'),
('Suzuki', 'Alto', 2022, 'Red', 'GHI-012', 'Economy', 'Manual', 'Petrol', 4, 2500.00, 'Available', 'Budget-friendly economy car for daily commutes.'),
('Mercedes', 'E-Class', 2023, 'Midnight Blue', 'JKL-345', 'Luxury', 'Automatic', 'Petrol', 5, 25000.00, 'Available', 'Premium luxury sedan with top-of-the-line amenities.'),
('Hyundai', 'Tucson', 2022, 'Grey', 'MNO-678', 'SUV', 'Automatic', 'Petrol', 5, 9000.00, 'Available', 'Modern SUV with excellent safety features.'),
('Toyota', 'HiAce', 2021, 'White', 'PQR-901', 'Van', 'Manual', 'Diesel', 12, 15000.00, 'Available', 'Spacious van ideal for group travel and cargo.'),
('BMW', '3 Series', 2023, 'Alpine White', 'STU-234', 'Luxury', 'Automatic', 'Petrol', 5, 20000.00, 'Maintenance', 'Premium sports sedan with dynamic performance.');
