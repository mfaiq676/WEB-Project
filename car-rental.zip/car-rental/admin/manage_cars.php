<?php
$pageTitle = 'Manage Cars';
require_once '../config/db.php';
requireLogin(); requireAdmin();

// ── DELETE ──────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Check no active bookings
    $active = $conn->query("SELECT id FROM bookings WHERE car_id=$id AND status IN ('Pending','Confirmed','Ongoing')")->num_rows;
    if ($active > 0) {
        setFlash('error', 'Cannot delete: this car has active bookings.');
    } else {
        $conn->query("DELETE FROM cars WHERE id=$id");
        setFlash('success', 'Car deleted successfully.');
    }
    redirect(SITE_URL.'/admin/manage_cars.php');
}

// ── ADD / EDIT SAVE ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id           = intval($_POST['id'] ?? 0);
    $brand        = sanitize($_POST['brand']        ?? '');
    $model        = sanitize($_POST['model']        ?? '');
    $year         = intval($_POST['year']           ?? date('Y'));
    $color        = sanitize($_POST['color']        ?? '');
    $plate        = sanitize($_POST['license_plate']?? '');
    $category     = sanitize($_POST['category']     ?? 'Sedan');
    $transmission = sanitize($_POST['transmission'] ?? 'Automatic');
    $fuel_type    = sanitize($_POST['fuel_type']    ?? 'Petrol');
    $seats        = intval($_POST['seats']          ?? 5);
    $price        = floatval($_POST['price_per_day']?? 0);
    $status       = sanitize($_POST['status']       ?? 'Available');
    $description  = sanitize($_POST['description']  ?? '');

    if (empty($brand) || empty($model) || empty($plate) || $price <= 0) {
        setFlash('error', 'Brand, model, license plate and price are required.');
    } else {
        if ($id) {
            // 13 placeholders -> 13 types (ssisssssidssi) -> 13 variables
            $stmt = $conn->prepare("UPDATE cars SET brand=?,model=?,year=?,color=?,license_plate=?,category=?,transmission=?,fuel_type=?,seats=?,price_per_day=?,status=?,description=? WHERE id=?");
            $stmt->bind_param("ssisssssidssi", $brand,$model,$year,$color,$plate,$category,$transmission,$fuel_type,$seats,$price,$status,$description,$id);
            $msg = 'Car updated successfully.';
        } else {
            // 12 placeholders -> 12 types (ssisssssidss) -> 12 variables
            $stmt = $conn->prepare("INSERT INTO cars (brand,model,year,color,license_plate,category,transmission,fuel_type,seats,price_per_day,status,description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssisssssidss", $brand,$model,$year,$color,$plate,$category,$transmission,$fuel_type,$seats,$price,$status,$description);
            $msg = 'Car added successfully.';
        }
        if ($stmt->execute()) {
            setFlash('success', $msg);
        } else {
            setFlash('error', 'Error: ' . $conn->error);
        }
    }
    redirect(SITE_URL.'/admin/manage_cars.php');
}

// ── FETCH EDIT CAR ──────────────────────────────────────
$editCar = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editCar = $conn->query("SELECT * FROM cars WHERE id=".intval($_GET['edit']))->fetch_assoc();
}

// ── SEARCH + FILTER LIST ────────────────────────────────
$search  = sanitize($_GET['q']        ?? '');
$catF    = sanitize($_GET['category'] ?? '');
$statF   = sanitize($_GET['status']   ?? '');
$where   = ['1=1'];
if ($search) $where[] = "(brand LIKE '%$search%' OR model LIKE '%$search%' OR license_plate LIKE '%$search%')";
if ($catF)   $where[] = "category='$catF'";
if ($statF)  $where[] = "status='$statF'";
$cars = $conn->query("SELECT * FROM cars WHERE ".implode(' AND ',$where)." ORDER BY created_at DESC");

require_once 'admin_header.php';
?>

<div class="row g-4">
    <!-- Form Panel -->
    <div class="col-lg-4" data-aos="fade-right">
        <div class="form-card sticky-top" style="top:80px">
            <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.2rem;margin-bottom:1.5rem">
                <i class="fas fa-<?=$editCar?'edit':'plus-circle'?> me-2 text-accent"></i>
                <?=$editCar?'Edit Car':'Add New Car'?>
            </h5>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="id" value="<?=$editCar?$editCar['id']:0?>">
                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label">Brand *</label>
                        <input type="text" name="brand" class="form-control" required
                               value="<?=htmlspecialchars($editCar['brand']??'')?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Model *</label>
                        <input type="text" name="model" class="form-control" required
                               value="<?=htmlspecialchars($editCar['model']??'')?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Year *</label>
                        <input type="number" name="year" class="form-control" min="2000" max="<?=date('Y')+1?>" required
                               value="<?=htmlspecialchars($editCar['year']??date('Y'))?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Color</label>
                        <input type="text" name="color" class="form-control"
                               value="<?=htmlspecialchars($editCar['color']??'')?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">License Plate *</label>
                        <input type="text" name="license_plate" class="form-control" required
                               placeholder="e.g. ABC-123"
                               value="<?=htmlspecialchars($editCar['license_plate']??'')?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select">
                            <?php foreach(['Economy','Sedan','SUV','Luxury','Van'] as $c): ?>
                            <option <?=($editCar['category']??'')===$c?'selected':''?>><?=$c?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label">Seats</label>
                        <input type="number" name="seats" class="form-control" min="2" max="20"
                               value="<?=htmlspecialchars($editCar['seats']??5)?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Transmission</label>
                        <select name="transmission" class="form-select">
                            <option <?=($editCar['transmission']??'')==='Automatic'?'selected':''?>>Automatic</option>
                            <option <?=($editCar['transmission']??'')==='Manual'?'selected':''?>>Manual</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label">Fuel Type</label>
                        <select name="fuel_type" class="form-select">
                            <?php foreach(['Petrol','Diesel','Electric','Hybrid'] as $f): ?>
                            <option <?=($editCar['fuel_type']??'')===$f?'selected':''?>><?=$f?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Price Per Day (PKR) *</label>
                        <input type="number" name="price_per_day" class="form-control" step="100" min="0" required
                               value="<?=htmlspecialchars($editCar['price_per_day']??'')?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <?php foreach(['Available','Rented','Maintenance'] as $st): ?>
                            <option <?=($editCar['status']??'')===$st?'selected':''?>><?=$st?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3"><?=htmlspecialchars($editCar['description']??'')?></textarea>
                    </div>
                    <div class="col-12 d-grid gap-2">
                        <button type="submit" class="btn-primary-custom text-center" style="padding:0.65rem">
                            <i class="fas fa-save me-2"></i><?=$editCar?'Update Car':'Add Car'?>
                        </button>
                        <?php if ($editCar): ?>
                        <a href="manage_cars.php" class="btn btn-outline-secondary btn-sm rounded-3">Cancel</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Cars Table -->
    <div class="col-lg-8" data-aos="fade-left">
        <!-- Search/Filter Bar -->
        <form method="GET" class="d-flex gap-2 flex-wrap mb-3">
            <input type="text" name="q" class="form-control" style="max-width:200px" placeholder="Search..." value="<?=htmlspecialchars($search)?>">
            <select name="category" class="form-select" style="max-width:140px">
                <option value="">All Categories</option>
                <?php foreach(['Economy','Sedan','SUV','Luxury','Van'] as $c): ?>
                <option <?=$catF===$c?'selected':''?>><?=$c?></option>
                <?php endforeach; ?>
            </select>
            <select name="status" class="form-select" style="max-width:140px">
                <option value="">All Status</option>
                <?php foreach(['Available','Rented','Maintenance'] as $st): ?>
                <option <?=$statF===$st?'selected':''?>><?=$st?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-outline-secondary rounded-3"><i class="fas fa-search"></i></button>
            <a href="manage_cars.php" class="btn btn-outline-secondary rounded-3"><i class="fas fa-times"></i></a>
        </form>

        <div class="table-custom">
            <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin:0">
                    Fleet — <?=$cars->num_rows?> car(s)
                </h6>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr><?php foreach(['Car','Category','Plate','Price/Day','Status','Actions'] as $h): ?>
                        <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.78rem;text-transform:uppercase;letter-spacing:1px;padding:0.85rem 1rem;border:none;white-space:nowrap"><?=$h?></th>
                        <?php endforeach; ?></tr>
                    </thead>
                    <tbody>
                        <?php if($cars->num_rows===0): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No cars found.</td></tr>
                        <?php else: while($car=$cars->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <div style="font-size:1.5rem;display:inline;margin-right:8px">🚘</div>
                                <div style="display:inline-block;vertical-align:middle">
                                    <strong style="font-size:0.9rem"><?=htmlspecialchars($car['brand'].' '.$car['model'])?></strong><br>
                                    <small class="text-muted"><?=$car['year']?> · <?=$car['color']?> · <?=$car['seats']?> seats</small>
                                </div>
                            </td>
                            <td><small><?=$car['category']?><br><span class="text-muted"><?=$car['transmission']?></span></small></td>
                            <td><code style="font-size:0.82rem"><?=$car['license_plate']?></code></td>
                            <td><strong style="color:var(--accent)"><?=formatPrice($car['price_per_day'])?></strong></td>
                            <td>
                                <?php $bClass=['Available'=>'badge-available','Rented'=>'badge-rented','Maintenance'=>'badge-maintenance'][$car['status']]??''; ?>
                                <span class="car-badge position-static <?=$bClass?>"><?=$car['status']?></span>
                            </td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="?edit=<?=$car['id']?>" class="btn btn-sm btn-outline-primary rounded-3" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?=$car['id']?>" class="btn btn-sm btn-outline-danger rounded-3 btn-delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'admin_footer.php'; ?>
