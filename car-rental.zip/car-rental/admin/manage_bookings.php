<?php
$pageTitle = 'Manage Bookings';
require_once '../config/db.php';
requireLogin(); requireAdmin();

// ── UPDATE STATUS ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $bid     = intval($_POST['booking_id']);
    $status  = sanitize($_POST['status']);
    $payment = sanitize($_POST['payment_status']);
    $allowed = ['Pending','Confirmed','Ongoing','Completed','Cancelled'];

    if (in_array($status, $allowed)) {
        $stmt = $conn->prepare("UPDATE bookings SET status=?, payment_status=? WHERE id=?");
        $stmt->bind_param("ssi", $status, $payment, $bid);
        $stmt->execute();

        // Sync car status
        $booking = $conn->query("SELECT car_id FROM bookings WHERE id=$bid")->fetch_assoc();
        if ($booking) {
            $carId = $booking['car_id'];
            if ($status === 'Ongoing')   $conn->query("UPDATE cars SET status='Rented'    WHERE id=$carId");
            if (in_array($status, ['Completed','Cancelled'])) {
                // Only free if no other active booking for this car
                $active = $conn->query("SELECT id FROM bookings WHERE car_id=$carId AND id!=$bid AND status IN ('Confirmed','Ongoing')")->num_rows;
                if ($active === 0) $conn->query("UPDATE cars SET status='Available' WHERE id=$carId");
            }
        }
        setFlash('success', "Booking #$bid updated.");
    }
    redirect(SITE_URL.'/admin/manage_bookings.php');
}

// ── DELETE ──────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM bookings WHERE id=$id");
    setFlash('success', "Booking #$id deleted.");
    redirect(SITE_URL.'/admin/manage_bookings.php');
}

// ── FILTERS ─────────────────────────────────────────────
$statusF  = sanitize($_GET['status']  ?? '');
$searchF  = sanitize($_GET['q']       ?? '');
$dateFrom = sanitize($_GET['from']    ?? '');
$dateTo   = sanitize($_GET['to']      ?? '');

$where = ['1=1'];
if ($statusF)  $where[] = "b.status='$statusF'";
if ($searchF)  $where[] = "(u.full_name LIKE '%$searchF%' OR u.email LIKE '%$searchF%' OR c.brand LIKE '%$searchF%' OR c.model LIKE '%$searchF%')";
if ($dateFrom) $where[] = "b.pickup_date >= '$dateFrom'";
if ($dateTo)   $where[] = "b.pickup_date <= '$dateTo'";

$bookings = $conn->query("
    SELECT b.*, u.full_name, u.email, u.phone, c.brand, c.model, c.category, c.price_per_day
    FROM bookings b
    JOIN users u ON b.user_id=u.id
    JOIN cars  c ON b.car_id=c.id
    WHERE ".implode(' AND ',$where)."
    ORDER BY b.created_at DESC
");

// ── EDIT MODAL DATA ─────────────────────────────────────
$editBooking = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editBooking = $conn->query("SELECT * FROM bookings WHERE id=".intval($_GET['edit']))->fetch_assoc();
}

require_once 'admin_header.php';
?>

<!-- Filter Bar -->
<div class="form-card mb-4" data-aos="fade-up">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label">Search Customer / Car</label>
            <input type="text" name="q" class="form-control" placeholder="Name, email, brand..."
                   value="<?=htmlspecialchars($searchF)?>">
        </div>
        <div class="col-md-2">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="">All</option>
                <?php foreach(['Pending','Confirmed','Ongoing','Completed','Cancelled'] as $s): ?>
                <option <?=$statusF===$s?'selected':''?>><?=$s?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label">From Date</label>
            <input type="date" name="from" class="form-control" value="<?=htmlspecialchars($dateFrom)?>">
        </div>
        <div class="col-md-2">
            <label class="form-label">To Date</label>
            <input type="date" name="to" class="form-control" value="<?=htmlspecialchars($dateTo)?>">
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn-primary-custom flex-fill text-center" style="padding:0.6rem">
                <i class="fas fa-filter me-1"></i>Filter
            </button>
            <a href="manage_bookings.php" class="btn btn-outline-secondary rounded-3 px-3">
                <i class="fas fa-times"></i>
            </a>
        </div>
    </form>
</div>

<!-- Status Badges Summary -->
<div class="d-flex gap-2 flex-wrap mb-3" data-aos="fade-up">
    <?php
    $statusCounts = [];
    $scQ = $conn->query("SELECT status, COUNT(*) c FROM bookings GROUP BY status");
    while($r=$scQ->fetch_assoc()) $statusCounts[$r['status']] = $r['c'];
    $allTotal = array_sum($statusCounts);
    ?>
    <span class="status-badge status-pending" style="font-size:0.82rem;padding:5px 14px">
        <?=$statusCounts['Pending']??0?> Pending
    </span>
    <span class="status-badge status-confirmed" style="font-size:0.82rem;padding:5px 14px">
        <?=$statusCounts['Confirmed']??0?> Confirmed
    </span>
    <span class="status-badge status-ongoing" style="font-size:0.82rem;padding:5px 14px">
        <?=$statusCounts['Ongoing']??0?> Ongoing
    </span>
    <span class="status-badge status-completed" style="font-size:0.82rem;padding:5px 14px">
        <?=$statusCounts['Completed']??0?> Completed
    </span>
    <span class="status-badge status-cancelled" style="font-size:0.82rem;padding:5px 14px">
        <?=$statusCounts['Cancelled']??0?> Cancelled
    </span>
    <span class="ms-auto text-muted" style="font-size:0.88rem;align-self:center">
        Showing <?=$bookings->num_rows?> of <?=$allTotal?> bookings
    </span>
</div>

<!-- Bookings Table -->
<div class="table-custom" data-aos="fade-up">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr><?php foreach(['#','Customer','Car','Pickup','Return','Days','Amount','Status','Payment','Actions'] as $h): ?>
                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;padding:0.9rem 0.75rem;border:none;white-space:nowrap"><?=$h?></th>
                <?php endforeach; ?></tr>
            </thead>
            <tbody>
                <?php if($bookings->num_rows===0): ?>
                <tr><td colspan="10" class="text-center py-5 text-muted">No bookings found for the selected filters.</td></tr>
                <?php else: while($b=$bookings->fetch_assoc()): ?>
                <tr>
                    <td class="px-3" style="font-size:0.82rem;color:var(--text-muted)">#<?=$b['id']?></td>
                    <td>
                        <strong style="font-size:0.88rem"><?=htmlspecialchars($b['full_name'])?></strong><br>
                        <small class="text-muted"><?=htmlspecialchars($b['email'])?></small>
                    </td>
                    <td>
                        <span style="font-size:0.88rem"><?=htmlspecialchars($b['brand'].' '.$b['model'])?></span><br>
                        <small class="text-muted"><?=$b['category']?></small>
                    </td>
                    <td style="font-size:0.85rem;white-space:nowrap"><?=date('d M Y',strtotime($b['pickup_date']))?></td>
                    <td style="font-size:0.85rem;white-space:nowrap"><?=date('d M Y',strtotime($b['return_date']))?></td>
                    <td style="font-size:0.88rem;text-align:center"><?=$b['total_days']?>d</td>
                    <td><strong style="font-size:0.88rem;color:var(--accent)"><?=formatPrice($b['total_price'])?></strong></td>
                    <td><span class="status-badge status-<?=strtolower($b['status'])?>"><?=$b['status']?></span></td>
                    <td>
                        <span class="status-badge <?=$b['payment_status']==='Paid'?'status-completed':'status-pending'?>">
                            <?=$b['payment_status']?>
                        </span>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <button type="button" class="btn btn-sm btn-outline-primary rounded-3"
                                    data-bs-toggle="modal" data-bs-target="#editModal"
                                    data-id="<?=$b['id']?>"
                                    data-status="<?=$b['status']?>"
                                    data-payment="<?=$b['payment_status']?>"
                                    title="Update Status">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?delete=<?=$b['id']?>" class="btn btn-sm btn-outline-danger rounded-3 btn-delete" title="Delete">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit Status Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--primary);color:#fff">
                <h6 class="modal-title" style="font-family:'Rajdhani',sans-serif">Update Booking #<span id="modalId"></span></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="booking_id" id="modalBookingId">
                    <div class="mb-3">
                        <label class="form-label">Booking Status</label>
                        <select name="status" id="modalStatus" class="form-select">
                            <?php foreach(['Pending','Confirmed','Ongoing','Completed','Cancelled'] as $s): ?>
                            <option><?=$s?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Payment Status</label>
                        <select name="payment_status" id="modalPayment" class="form-select">
                            <option>Unpaid</option>
                            <option>Paid</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn-primary-custom" style="padding:0.5rem 1.5rem">
                        <i class="fas fa-save me-1"></i>Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('editModal').addEventListener('show.bs.modal', function(e) {
    const btn = e.relatedTarget;
    document.getElementById('modalId').textContent        = btn.dataset.id;
    document.getElementById('modalBookingId').value       = btn.dataset.id;
    document.getElementById('modalStatus').value          = btn.dataset.status;
    document.getElementById('modalPayment').value         = btn.dataset.payment;
});
</script>

<?php require_once 'admin_footer.php'; ?>
