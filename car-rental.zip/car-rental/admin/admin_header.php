<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? $pageTitle . ' | Admin | ' . SITE_NAME : 'Admin | ' . SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<div class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <i class="fas fa-car me-2"></i>Drive<span>Ease</span>
        <div style="font-size:0.7rem;color:rgba(255,255,255,0.4);font-family:'Inter',sans-serif;font-weight:400;letter-spacing:1px;margin-top:2px">ADMIN PANEL</div>
    </div>
    <nav class="sidebar-nav">
        <a href="dashboard.php"        class="<?= $currentPage==='dashboard.php'?'active':'' ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="manage_cars.php"      class="<?= $currentPage==='manage_cars.php'?'active':'' ?>"><i class="fas fa-car"></i> Manage Cars</a>
        <a href="manage_bookings.php"  class="<?= $currentPage==='manage_bookings.php'?'active':'' ?>"><i class="fas fa-calendar-check"></i> Bookings</a>
        <a href="manage_users.php"     class="<?= $currentPage==='manage_users.php'?'active':'' ?>"><i class="fas fa-users"></i> Users</a>
        <hr style="border-color:rgba(255,255,255,0.1);margin:0.5rem 1rem">
        <a href="<?= SITE_URL ?>"><i class="fas fa-home"></i> View Site</a>
        <a href="<?= SITE_URL ?>/auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
</div>

<div class="admin-content">
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-secondary d-lg-none"><i class="fas fa-bars"></i></button>
            <h6 style="margin:0;font-family:'Rajdhani',sans-serif;font-size:1.1rem"><?= $pageTitle ?? 'Admin' ?></h6>
        </div>
        <div class="d-flex align-items-center gap-3">
            <span style="font-size:0.88rem;color:var(--text-muted)">
                <i class="fas fa-user-shield me-1 text-accent"></i><?= htmlspecialchars($_SESSION['user_name']) ?>
            </span>
            <a href="<?= SITE_URL ?>/auth/logout.php" class="btn btn-sm btn-outline-danger rounded-3"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    <?php $flash = getFlash(); if ($flash): ?>
    <div class="px-4 pt-3">
        <div class="alert-custom alert-<?= $flash['type']==='success'?'success':'error' ?>">
            <i class="fas fa-<?= $flash['type']==='success'?'check-circle':'exclamation-circle' ?> me-2"></i>
            <?= htmlspecialchars($flash['message']) ?>
        </div>
    </div>
    <?php endif; ?>
    <div class="admin-main">
