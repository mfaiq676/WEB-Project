<?php
$pageTitle = 'Dashboard';
require_once '../config/db.php';
requireLogin(); requireAdmin();
require_once 'admin_header.php';

function safeCount($conn, $sql, $col) {
    $res = $conn->query($sql);
    if ($res === false) return 0;
    $row = $res->fetch_assoc();
    return $row ? $row[$col] : 0;
}

$totalCars     = safeCount($conn, "SELECT COUNT(*) c FROM cars", 'c');
$availableCars = safeCount($conn, "SELECT COUNT(*) c FROM cars WHERE status='Available'", 'c');
$rentedCars    = safeCount($conn, "SELECT COUNT(*) c FROM cars WHERE status='Rented'", 'c');
$totalUsers    = safeCount($conn, "SELECT COUNT(*) c FROM users WHERE role='user'", 'c');
$totalBookings = safeCount($conn, "SELECT COUNT(*) c FROM bookings", 'c');
$pendingBook   = safeCount($conn, "SELECT COUNT(*) c FROM bookings WHERE status='Pending'", 'c');
$activeBook    = safeCount($conn, "SELECT COUNT(*) c FROM bookings WHERE status IN ('Confirmed','Ongoing')", 'c');
$revenue       = safeCount($conn, "SELECT COALESCE(SUM(total_price),0) s FROM bookings WHERE status='Completed'", 's');

// Monthly revenue last 6 months
$revQ = $conn->query("
    SELECT DATE_FORMAT(created_at,'%Y-%m') ym, DATE_FORMAT(created_at,'%b %Y') mo,
           COALESCE(SUM(total_price),0) rev
    FROM bookings WHERE status='Completed'
      AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY ym, mo ORDER BY ym
");
$revLabels=$revData=[];
if ($revQ) {
    while($r=$revQ->fetch_assoc()){$revLabels[]=$r['mo'];$revData[]=(float)$r['rev'];}
}

// Bookings by status
$bsQ=$conn->query("SELECT status,COUNT(*) c FROM bookings GROUP BY status");
$bsLabels=$bsData=[];
if ($bsQ) {
    while($r=$bsQ->fetch_assoc()){$bsLabels[]=$r['status'];$bsData[]=(int)$r['c'];}
}

// Cars by category
$catQ=$conn->query("SELECT category,COUNT(*) c FROM cars GROUP BY category");
$catLabels=$catData=[];
if ($catQ) {
    while($r=$catQ->fetch_assoc()){$catLabels[]=$r['category'];$catData[]=(int)$r['c'];}
}

// Recent bookings
$recent=$conn->query("
    SELECT b.*,u.full_name,c.brand,c.model FROM bookings b
    JOIN users u ON b.user_id=u.id JOIN cars c ON b.car_id=c.id
    ORDER BY b.created_at DESC LIMIT 8
");
$maint=$conn->query("SELECT * FROM cars WHERE status='Maintenance' LIMIT 4");
?>

<!-- Stats -->
<div class="row g-4 mb-4">
<?php
$stats=[
    ['🚗',$totalCars,'Total Cars','blue'],
    ['✅',$availableCars,'Available','green'],
    ['👥',$totalUsers,'Users','amber'],
    ['📋',$totalBookings,'Bookings',''],
    ['⏳',$pendingBook,'Pending','amber'],
    ['🔑',$activeBook,'Active Rentals','blue'],
    ['🔧',$rentedCars,'Rented Out','red'],
    ['💰',number_format($revenue,0),'Revenue (PKR)','green'],
];
foreach($stats as $i=>$s): ?>
<div class="col-xl-3 col-md-4 col-sm-6" data-aos="fade-up" data-aos-delay="<?=$i*50?>">
    <div class="stat-card <?=$s[3]?>">
        <div class="stat-icon"><?=$s[0]?></div>
        <div class="stat-val" style="font-size:<?=strlen((string)$s[1])>6?'1.4rem':'2.2rem'?>"><?=$s[1]?></div>
        <div class="stat-lbl"><?=$s[2]?></div>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- Charts -->
<div class="row g-4 mb-4">
    <div class="col-lg-8" data-aos="fade-up">
        <div class="form-card h-100">
            <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.15rem;margin-bottom:1.5rem">
                <i class="fas fa-chart-line me-2 text-accent"></i>Monthly Revenue (Last 6 Months)
            </h6>
            <canvas id="revenueChart" height="100"></canvas>
        </div>
    </div>
    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
        <div class="form-card h-100">
            <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.15rem;margin-bottom:1.5rem">
                <i class="fas fa-chart-pie me-2 text-accent"></i>Bookings by Status
            </h6>
            <canvas id="statusChart" height="180"></canvas>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-4" data-aos="fade-up">
        <div class="form-card h-100">
            <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.15rem;margin-bottom:1.5rem">
                <i class="fas fa-car me-2 text-accent"></i>Fleet by Category
            </h6>
            <canvas id="categoryChart" height="200"></canvas>
            <?php if($maint->num_rows>0): ?>
            <hr class="mt-4">
            <div style="font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:0.75rem">🔧 In Maintenance</div>
            <?php while($mc=$maint->fetch_assoc()): ?>
            <div style="font-size:0.87rem;padding:0.4rem 0;border-bottom:1px solid var(--border)">
                <?=htmlspecialchars($mc['brand'].' '.$mc['model'])?><span class="float-end text-muted"><?=$mc['year']?></span>
            </div>
            <?php endwhile; endif; ?>
        </div>
    </div>
    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
        <div class="table-custom">
            <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.15rem;margin:0"><i class="fas fa-clock me-2 text-accent"></i>Recent Bookings</h6>
                <a href="manage_bookings.php" style="color:var(--accent);font-size:0.88rem;font-weight:600">View All →</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr><?php foreach(['#','Customer','Car','Dates','Amount','Status'] as $h): ?>
                        <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.78rem;text-transform:uppercase;letter-spacing:1px;padding:0.85rem 1rem;border:none"><?=$h?></th>
                        <?php endforeach; ?></tr>
                    </thead>
                    <tbody>
                        <?php while($b=$recent->fetch_assoc()): ?>
                        <tr>
                            <td class="px-3 text-muted" style="font-size:0.82rem">#<?=$b['id']?></td>
                            <td style="font-size:0.88rem"><strong><?=htmlspecialchars($b['full_name'])?></strong></td>
                            <td style="font-size:0.88rem"><?=htmlspecialchars($b['brand'].' '.$b['model'])?></td>
                            <td style="font-size:0.82rem;color:var(--text-muted)"><?=date('d M',strtotime($b['pickup_date']))?> → <?=date('d M',strtotime($b['return_date']))?></td>
                            <td style="font-size:0.88rem"><strong><?=formatPrice($b['total_price'])?></strong></td>
                            <td><span class="status-badge status-<?=strtolower($b['status'])?>"><?=$b['status']?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
Chart.defaults.font = { family: 'Inter, sans-serif', size: 12 };
Chart.defaults.color = '#6c757d';

new Chart(document.getElementById('revenueChart'),{
    type:'line',
    data:{
        labels:<?=json_encode($revLabels?:['No data'])?>,
        datasets:[{label:'Revenue (PKR)',data:<?=json_encode($revData?:[0])?>,
            borderColor:'#e63946',backgroundColor:'rgba(230,57,70,0.08)',
            borderWidth:2.5,fill:true,tension:0.4,pointBackgroundColor:'#e63946',pointRadius:5}]
    },
    options:{responsive:true,plugins:{legend:{display:false}},
        scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
});

new Chart(document.getElementById('statusChart'),{
    type:'doughnut',
    data:{labels:<?=json_encode($bsLabels?:['None'])?>,
        datasets:[{data:<?=json_encode($bsData?:[1])?>,
            backgroundColor:['#4361ee','#2a9d8f','#e9c46a','#e63946','#6c757d'],borderWidth:0,hoverOffset:6}]},
    options:{responsive:true,plugins:{legend:{position:'bottom',labels:{padding:15,boxWidth:12}}},cutout:'65%'}
});

new Chart(document.getElementById('categoryChart'),{
    type:'bar',
    data:{labels:<?=json_encode($catLabels?:['None'])?>,
        datasets:[{label:'Cars',data:<?=json_encode($catData?:[0])?>,
            backgroundColor:['#e63946','#4361ee','#2a9d8f','#e9c46a','#f4a261'],borderRadius:6,borderSkipped:false}]},
    options:{responsive:true,plugins:{legend:{display:false}},
        scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
});
</script>

<?php require_once 'admin_footer.php'; ?>
