<?php
$pageTitle = 'Manage Users';
require_once '../config/db.php';
requireLogin(); requireAdmin();

// ── DELETE USER ─────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id == $_SESSION['user_id']) {
        setFlash('error', 'You cannot delete your own account.');
    } else {
        $conn->query("DELETE FROM users WHERE id=$id AND role='user'");
        setFlash('success', 'User deleted successfully.');
    }
    redirect(SITE_URL.'/admin/manage_users.php');
}

// ── TOGGLE ROLE ─────────────────────────────────────────
if (isset($_GET['toggle_role']) && is_numeric($_GET['toggle_role'])) {
    $id   = intval($_GET['toggle_role']);
    $user = $conn->query("SELECT role FROM users WHERE id=$id")->fetch_assoc();
    if ($user && $id != $_SESSION['user_id']) {
        $newRole = $user['role'] === 'admin' ? 'user' : 'admin';
        $conn->query("UPDATE users SET role='$newRole' WHERE id=$id");
        setFlash('success', "User role updated to $newRole.");
    }
    redirect(SITE_URL.'/admin/manage_users.php');
}

// ── SEARCH ──────────────────────────────────────────────
$searchF = sanitize($_GET['q']    ?? '');
$roleF   = sanitize($_GET['role'] ?? '');
$where   = ['1=1'];
if ($searchF) $where[] = "(full_name LIKE '%$searchF%' OR email LIKE '%$searchF%' OR phone LIKE '%$searchF%')";
if ($roleF)   $where[] = "role='$roleF'";

$users = $conn->query("
    SELECT u.*,
           COUNT(b.id)                                      AS total_bookings,
           COALESCE(SUM(CASE WHEN b.status='Completed' THEN b.total_price ELSE 0 END),0) AS total_spent
    FROM users u
    LEFT JOIN bookings b ON u.id=b.user_id
    WHERE ".implode(' AND ',$where)."
    GROUP BY u.id
    ORDER BY u.created_at DESC
");

$totalUsers  = $conn->query("SELECT COUNT(*) c FROM users WHERE role='user'")->fetch_assoc()['c'];
$totalAdmins = $conn->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch_assoc()['c'];
$newThisMonth= $conn->query("SELECT COUNT(*) c FROM users WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetch_assoc()['c'];

require_once 'admin_header.php';
?>

<!-- Mini Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-4" data-aos="fade-up">
        <div class="stat-card blue">
            <div class="stat-icon">👥</div>
            <div class="stat-val"><?=$totalUsers?></div>
            <div class="stat-lbl">Total Users</div>
        </div>
    </div>
    <div class="col-md-4" data-aos="fade-up" data-aos-delay="80">
        <div class="stat-card red">
            <div class="stat-icon">🛡️</div>
            <div class="stat-val"><?=$totalAdmins?></div>
            <div class="stat-lbl">Admins</div>
        </div>
    </div>
    <div class="col-md-4" data-aos="fade-up" data-aos-delay="160">
        <div class="stat-card green">
            <div class="stat-icon">🆕</div>
            <div class="stat-val"><?=$newThisMonth?></div>
            <div class="stat-lbl">New This Month</div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="form-card mb-4" data-aos="fade-up">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-5">
            <label class="form-label">Search</label>
            <input type="text" name="q" class="form-control" placeholder="Name, email, phone..."
                   value="<?=htmlspecialchars($searchF)?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">Role</label>
            <select name="role" class="form-select">
                <option value="">All Roles</option>
                <option <?=$roleF==='user'?'selected':''?>>user</option>
                <option <?=$roleF==='admin'?'selected':''?>>admin</option>
            </select>
        </div>
        <div class="col-md-4 d-flex gap-2">
            <button type="submit" class="btn-primary-custom flex-fill text-center" style="padding:0.6rem">
                <i class="fas fa-search me-1"></i>Search
            </button>
            <a href="manage_users.php" class="btn btn-outline-secondary rounded-3 px-3">
                <i class="fas fa-times"></i>
            </a>
        </div>
    </form>
</div>

<!-- Users Table -->
<div class="table-custom" data-aos="fade-up">
    <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
        <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin:0">
            <i class="fas fa-users me-2 text-accent"></i>All Users (<?=$users->num_rows?>)
        </h6>
    </div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr><?php foreach(['User','Contact','Role','Bookings','Total Spent','Joined','Actions'] as $h): ?>
                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.75rem;text-transform:uppercase;letter-spacing:1px;padding:0.9rem 1rem;border:none;white-space:nowrap"><?=$h?></th>
                <?php endforeach; ?></tr>
            </thead>
            <tbody>
                <?php if($users->num_rows===0): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No users found.</td></tr>
                <?php else: while($u=$users->fetch_assoc()): ?>
                <tr>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div style="width:36px;height:36px;background:linear-gradient(135deg,var(--accent),#c1121f);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:0.9rem;flex-shrink:0">
                                <?=strtoupper(substr($u['full_name'],0,1))?>
                            </div>
                            <div>
                                <strong style="font-size:0.9rem"><?=htmlspecialchars($u['full_name'])?></strong>
                                <?php if($u['id']==$_SESSION['user_id']): ?>
                                <span style="font-size:0.7rem;background:#e63946;color:#fff;padding:1px 6px;border-radius:10px;margin-left:4px">You</span>
                                <?php endif; ?>
                                <br><small class="text-muted">#<?=$u['id']?></small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <small><?=htmlspecialchars($u['email'])?></small><br>
                        <small class="text-muted"><?=$u['phone']??'—'?></small>
                    </td>
                    <td>
                        <span class="status-badge <?=$u['role']==='admin'?'status-ongoing':'status-completed'?>">
                            <?=$u['role']==='admin'?'🛡️ Admin':'👤 User'?>
                        </span>
                    </td>
                    <td style="text-align:center">
                        <strong><?=$u['total_bookings']?></strong>
                    </td>
                    <td><strong style="color:var(--accent)"><?=formatPrice($u['total_spent'])?></strong></td>
                    <td style="font-size:0.82rem;color:var(--text-muted);white-space:nowrap">
                        <?=date('d M Y',strtotime($u['created_at']))?>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <?php if($u['id']!=$_SESSION['user_id']): ?>
                            <a href="?toggle_role=<?=$u['id']?>"
                               class="btn btn-sm btn-outline-secondary rounded-3"
                               title="<?=$u['role']==='admin'?'Demote to User':'Promote to Admin'?>"
                               onclick="return confirm('Change this user\'s role?')">
                                <i class="fas fa-<?=$u['role']==='admin'?'user-minus':'user-plus'?>"></i>
                            </a>
                            <a href="?delete=<?=$u['id']?>"
                               class="btn btn-sm btn-outline-danger rounded-3 btn-delete"
                               title="Delete User">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php else: ?>
                            <span class="text-muted" style="font-size:0.8rem">—</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- User Detail Modal trigger per row (optional improvement placeholder) -->
<div class="mt-4 form-card" data-aos="fade-up">
    <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin-bottom:0.75rem">
        <i class="fas fa-info-circle me-2 text-accent"></i>Admin Notes
    </h6>
    <ul class="list-unstyled mb-0" style="font-size:0.88rem;color:var(--text-muted);line-height:2.2">
        <li><i class="fas fa-shield-alt text-accent me-2"></i>You cannot delete your own admin account.</li>
        <li><i class="fas fa-user-plus text-accent me-2"></i>Promoting a user to admin gives full panel access.</li>
        <li><i class="fas fa-exclamation-triangle text-warning me-2"></i>Deleting a user also removes all their bookings (cascade).</li>
    </ul>
</div>

<?php require_once 'admin_footer.php'; ?>
