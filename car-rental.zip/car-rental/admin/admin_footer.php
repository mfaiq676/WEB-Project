    </div><!-- /.admin-main -->
</div><!-- /.admin-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>AOS.init({ duration: 600, once: true, offset: 30 });</script>
</body>
</html>
