// ============================================
// DriveEase Car Rental - Main JavaScript
// CS-309 | HITEC University Taxila
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ---- Auto-dismiss alerts after 4s ----
    const alerts = document.querySelectorAll('.alert-custom');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });

    // ---- Mobile sidebar toggle (admin) ----
    const sidebarToggle = document.getElementById('sidebarToggle');
    const adminSidebar  = document.getElementById('adminSidebar');
    if (sidebarToggle && adminSidebar) {
        sidebarToggle.addEventListener('click', () => {
            adminSidebar.classList.toggle('open');
        });
    }

    // ---- Date validation for booking form ----
    const pickupInput  = document.getElementById('pickup_date');
    const returnInput  = document.getElementById('return_date');
    const totalDaysEl  = document.getElementById('total_days');
    const totalPriceEl = document.getElementById('total_price');
    const pricePerDay  = parseFloat(document.getElementById('price_per_day')?.value || 0);

    if (pickupInput) {
        // Set min date to today
        const today = new Date().toISOString().split('T')[0];
        pickupInput.min = today;
        if (returnInput) returnInput.min = today;

        function updateBookingCalc() {
            const pickup = new Date(pickupInput.value);
            const ret    = new Date(returnInput.value);
            if (pickupInput.value && returnInput.value && ret > pickup) {
                const diff = Math.ceil((ret - pickup) / (1000 * 60 * 60 * 24));
                if (totalDaysEl)  totalDaysEl.textContent  = diff + ' day(s)';
                if (totalPriceEl) totalPriceEl.textContent = 'PKR ' + (diff * pricePerDay).toLocaleString();
            }
        }

        pickupInput.addEventListener('change', function () {
            if (returnInput) returnInput.min = this.value;
            updateBookingCalc();
        });
        if (returnInput) returnInput.addEventListener('change', updateBookingCalc);
    }

    // ---- Car search/filter ----
    const filterCategory    = document.getElementById('filterCategory');
    const filterTransmission= document.getElementById('filterTransmission');
    const filterMaxPrice    = document.getElementById('filterMaxPrice');
    const searchName        = document.getElementById('searchName');
    const carGrid           = document.getElementById('carGrid');

    function filterCars() {
        if (!carGrid) return;
        const cards = carGrid.querySelectorAll('.car-filter-item');
        const cat   = filterCategory?.value    || '';
        const trans = filterTransmission?.value || '';
        const maxP  = parseFloat(filterMaxPrice?.value) || Infinity;
        const name  = searchName?.value.toLowerCase() || '';

        cards.forEach(card => {
            const cardCat   = card.dataset.category    || '';
            const cardTrans = card.dataset.transmission || '';
            const cardPrice = parseFloat(card.dataset.price) || 0;
            const cardName  = (card.dataset.name || '').toLowerCase();

            const show = (!cat   || cardCat === cat)
                      && (!trans || cardTrans === trans)
                      && (cardPrice <= maxP)
                      && (!name  || cardName.includes(name));

            card.style.display = show ? '' : 'none';
        });
    }

    [filterCategory, filterTransmission, filterMaxPrice, searchName].forEach(el => {
        if (el) el.addEventListener('change', filterCars);
    });
    if (searchName) searchName.addEventListener('input', filterCars);

    // ---- Form validation ----
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // ---- Password toggle ----
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', function () {
            const input = document.querySelector(this.dataset.target);
            if (input) {
                const isPass = input.type === 'password';
                input.type   = isPass ? 'text' : 'password';
                this.innerHTML = isPass ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
            }
        });
    });

    // ---- Confirm delete ----
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function (e) {
            if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // ---- Navbar scroll effect ----
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 30px rgba(0,0,0,0.4)';
            } else {
                navbar.style.boxShadow = '0 2px 15px rgba(0,0,0,0.3)';
            }
        }
    });
});
