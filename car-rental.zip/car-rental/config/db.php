<?php
// ============================================
// Database Configuration
// Car Rental Management System
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '1234');
define('DB_NAME', 'car_rental_db');

define('SITE_NAME', 'DriveEase Car Rentals');
define('SITE_URL', 'http://localhost/car-rental');
define('CURRENCY', 'PKR');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("<div style='font-family:sans-serif;padding:20px;background:#fee;border:1px solid red;margin:20px;'>
        <h3>Database Connection Failed</h3>
        <p>" . $conn->connect_error . "</p>
        <p>Please check your database settings in <code>config/db.php</code></p>
    </div>");
}

$conn->set_charset("utf8");

// Session management
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper Functions
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . SITE_URL . "/auth/login.php");
        exit();
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header("Location: " . SITE_URL . "/index.php");
        exit();
    }
}

function sanitize($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($data)));
}

function formatPrice($amount) {
    return CURRENCY . ' ' . number_format($amount, 0);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
?>
