<?php
$pageTitle = 'Home';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

// Fetch featured available cars
$carsResult = $conn->query("SELECT * FROM cars WHERE status = 'Available' ORDER BY created_at DESC LIMIT 6");
?>

<!-- HERO -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content" data-aos="fade-right">
                <p class="hero-eyebrow">Pakistan's Premier Car Rental</p>
                <h1 class="hero-title">
                    Drive Your<br><span>Dream Car</span><br>Today
                </h1>
                <p class="hero-subtitle">
                    Choose from our premium fleet of vehicles. Transparent pricing, easy booking, and doorstep delivery across Taxila & Rawalpindi.
                </p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="user/browse_cars.php" class="btn-primary-custom">
                        <i class="fas fa-car me-2"></i>Browse Fleet
                    </a>
                    <?php if (!isLoggedIn()): ?>
                    <a href="auth/register.php" class="btn-outline-custom">
                        <i class="fas fa-user-plus me-2"></i>Get Started
                    </a>
                    <?php endif; ?>
                </div>
                <div class="hero-stats">
                    <?php
                    $totalCars     = $conn->query("SELECT COUNT(*) as c FROM cars")->fetch_assoc()['c'];
                    $availableCars = $conn->query("SELECT COUNT(*) as c FROM cars WHERE status='Available'")->fetch_assoc()['c'];
                    $totalBookings = $conn->query("SELECT COUNT(*) as c FROM bookings WHERE status='Completed'")->fetch_assoc()['c'];
                    ?>
                    <div class="stat-item">
                        <div class="stat-number"><?= $availableCars ?>+</div>
                        <div class="stat-label">Cars Available</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number"><?= $totalBookings ?>+</div>
                        <div class="stat-label">Happy Rentals</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">24/7</div>
                        <div class="stat-label">Support</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center" data-aos="fade-left" data-aos-delay="200">
                <div style="font-size: 14rem; line-height:1; filter: drop-shadow(0 20px 40px rgba(230,57,70,0.3));">🚗</div>
            </div>
        </div>
    </div>
</section>

<!-- SEARCH BAR -->
<section class="pt-4 mt-5">
    <div class="container">
        <div class="search-box" data-aos="fade-up">
            <form action="user/browse_cars.php" method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Search Car</label>
                        <input type="text" name="search" class="form-control" placeholder="Brand or model...">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select">
                            <option value="">All Types</option>
                            <option>Economy</option>
                            <option>Sedan</option>
                            <option>SUV</option>
                            <option>Luxury</option>
                            <option>Van</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Pickup Date</label>
                        <input type="date" name="pickup" class="form-control" min="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Return Date</label>
                        <input type="date" name="return" class="form-control" min="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn-primary-custom w-100">
                            <i class="fas fa-search me-2"></i>Find Cars
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- FEATURES -->
<section class="py-5 mt-4">
    <div class="container">
        <div class="section-header text-center" data-aos="fade-up">
            <p class="section-eyebrow">Why Choose DriveEase</p>
            <h2 class="section-title">The Smarter Way to Rent</h2>
            <div class="section-divider mx-auto"></div>
        </div>
        <div class="row g-4">
            <?php
            $features = [
                ['🛡️', 'Fully Insured', 'Every vehicle is fully insured. Drive with complete peace of mind.'],
                ['💰', 'Transparent Pricing', 'No hidden fees. What you see is what you pay.'],
                ['🔑', 'Easy Booking', 'Book online in under 3 minutes. Confirmation instant.'],
                ['🚗', 'Wide Fleet', 'From budget economy to luxury vehicles — we have it all.'],
                ['📍', 'Doorstep Pickup', 'We deliver the car to your location across Rawalpindi & Taxila.'],
                ['📞', '24/7 Support', 'Our team is always available to assist you.'],
            ];
            foreach ($features as $i => $f): ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?= $i * 80 ?>">
                <div class="feature-card">
                    <div class="feature-icon"><?= $f[0] ?></div>
                    <div class="feature-title"><?= $f[1] ?></div>
                    <p style="font-size:0.9rem;color:var(--text-muted);margin:0"><?= $f[2] ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- FEATURED CARS -->
<section class="py-5" style="background:var(--card-bg)">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4" data-aos="fade-up">
            <div>
                <p class="section-eyebrow">Available Now</p>
                <h2 class="section-title mb-0">Featured Vehicles</h2>
                <div class="section-divider"></div>
            </div>
            <a href="user/browse_cars.php" class="btn-primary-custom">View All <i class="fas fa-arrow-right ms-1"></i></a>
        </div>
        <div class="row g-4">
            <?php if ($carsResult && $carsResult->num_rows > 0):
                while ($car = $carsResult->fetch_assoc()): ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up">
                <div class="car-card">
                    <div style="position:relative;">
                        <div class="car-card-img">🚘</div>
                        <span class="car-badge badge-available">Available</span>
                    </div>
                    <div class="car-card-body">
                        <div class="car-name"><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></div>
                        <div class="car-category"><?= $car['category'] ?> · <?= $car['year'] ?></div>
                        <div class="car-specs">
                            <span class="spec-tag"><i class="fas fa-cog"></i><?= $car['transmission'] ?></span>
                            <span class="spec-tag"><i class="fas fa-gas-pump"></i><?= $car['fuel_type'] ?></span>
                            <span class="spec-tag"><i class="fas fa-users"></i><?= $car['seats'] ?> Seats</span>
                            <span class="spec-tag"><i class="fas fa-palette"></i><?= $car['color'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div>
                                <div class="car-price"><?= formatPrice($car['price_per_day']) ?> <span>/day</span></div>
                            </div>
                            <?php if (isLoggedIn()): ?>
                            <a href="user/book_car.php?id=<?= $car['id'] ?>" class="btn-primary-custom" style="padding:0.5rem 1.2rem;font-size:0.9rem;">
                                Book Now
                            </a>
                            <?php else: ?>
                            <a href="auth/login.php" class="btn-primary-custom" style="padding:0.5rem 1.2rem;font-size:0.9rem;">
                                Login to Book
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile;
            else: ?>
            <div class="col-12 text-center py-5 text-muted">No cars available at the moment.</div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- HOW IT WORKS -->
<section class="py-5">
    <div class="container">
        <div class="section-header text-center" data-aos="fade-up">
            <p class="section-eyebrow">Simple Process</p>
            <h2 class="section-title">How It Works</h2>
            <div class="section-divider mx-auto"></div>
        </div>
        <div class="row g-4 text-center">
            <?php
            $steps = [
                ['1', '🔍', 'Choose Your Car', 'Browse our fleet and pick the vehicle that fits your needs and budget.'],
                ['2', '📅', 'Make a Booking', 'Select pickup date, return date, and confirm your reservation online.'],
                ['3', '🚗', 'Drive Away', 'Pick up your car and enjoy the road. Return it when done.'],
            ];
            foreach ($steps as $step): ?>
            <div class="col-md-4" data-aos="fade-up">
                <div style="position:relative;">
                    <div style="width:60px;height:60px;background:var(--accent);border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Rajdhani',sans-serif;font-size:1.4rem;font-weight:700;color:#fff;margin:0 auto 1rem;">
                        <?= $step[0] ?>
                    </div>
                    <div style="font-size:2.5rem;margin-bottom:0.75rem"><?= $step[1] ?></div>
                    <h4 style="font-family:'Rajdhani',sans-serif;font-size:1.2rem;font-weight:700;margin-bottom:0.5rem"><?= $step[2] ?></h4>
                    <p style="color:var(--text-muted);font-size:0.9rem"><?= $step[3] ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA BANNER -->
<?php if (!isLoggedIn()): ?>
<section class="py-5" style="background:linear-gradient(135deg,var(--primary),#16213e)">
    <div class="container text-center" data-aos="fade-up">
        <h2 style="font-family:'Rajdhani',sans-serif;font-size:2.5rem;color:#fff;margin-bottom:1rem;">
            Ready to Hit the Road?
        </h2>
        <p style="color:rgba(255,255,255,0.7);margin-bottom:2rem;font-size:1.05rem;">
            Create your free account and book your first car in minutes.
        </p>
        <a href="auth/register.php" class="btn-primary-custom" style="font-size:1.05rem;padding:0.9rem 2.5rem;">
            <i class="fas fa-user-plus me-2"></i>Create Free Account
        </a>
    </div>
</section>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
