<?php
$pageTitle = 'Browse Cars';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

// Build query with filters — show ALL cars (availability shown via badge)
$where   = ["1=1"];
$params  = [];
$types   = '';

$search   = sanitize($_GET['search']   ?? '');
$category = sanitize($_GET['category'] ?? '');
$trans    = sanitize($_GET['transmission'] ?? '');
$minPrice = intval($_GET['min_price'] ?? 0);
$maxPrice = intval($_GET['max_price'] ?? 999999);
$sortBy   = sanitize($_GET['sort'] ?? 'newest');

if ($search) {
    // Filter purely by car name (brand + model)
    $where[]  = "(brand LIKE ? OR model LIKE ? OR CONCAT(brand,' ',model) LIKE ?)";
    $s = "%$search%";
    $params = array_merge($params, [$s, $s, $s]);
    $types .= 'sss';
}
if ($category) { $where[] = "category = ?"; $params[] = $category; $types .= 's'; }
if ($trans)    { $where[] = "transmission = ?"; $params[] = $trans;  $types .= 's'; }
$where[] = "price_per_day >= ?"; $params[] = $minPrice; $types .= 'i';
$where[] = "price_per_day <= ?"; $params[] = $maxPrice; $types .= 'i';

$orderMap = [
    'newest'      => 'created_at DESC',
    'price_asc'   => 'price_per_day ASC',
    'price_desc'  => 'price_per_day DESC',
    'name_asc'    => 'brand ASC',
];
$order = $orderMap[$sortBy] ?? 'created_at DESC';

// Show available cars first, then rented, then maintenance
$sql = "SELECT * FROM cars WHERE " . implode(' AND ', $where) . "
        ORDER BY FIELD(status,'Available','Rented','Maintenance'), $order";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $carsResult = $stmt->get_result();
} else {
    $carsResult = $conn->query($sql);
}

$totalCars = $carsResult->num_rows;
// Fetch all for display
$cars = [];
while ($r = $carsResult->fetch_assoc()) $cars[] = $r;
?>

<div class="page-header">
    <div class="container">
        <h1 style="font-family:'Rajdhani',sans-serif;font-size:2.2rem;margin:0">Browse Our Fleet</h1>
        <p style="color:rgba(255,255,255,0.7);margin:0.25rem 0 0">
            <?= $totalCars ?> vehicle<?= $totalCars != 1 ? 's' : '' ?> available
        </p>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4">

        <!-- Filters Sidebar -->
        <div class="col-lg-3" data-aos="fade-right">
            <div class="form-card sticky-top" style="top:80px">
                <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.2rem;margin-bottom:1.25rem">
                    <i class="fas fa-filter me-2 text-accent"></i>Filter Cars
                </h5>
                <form method="GET" id="filterForm">
                    <div class="mb-3">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Brand or model..."
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select">
                            <option value="">All Categories</option>
                            <?php foreach (['Economy','Sedan','SUV','Luxury','Van'] as $cat): ?>
                            <option <?= $category===$cat?'selected':'' ?>><?= $cat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Transmission</label>
                        <select name="transmission" class="form-select">
                            <option value="">Any</option>
                            <option <?= $trans==='Automatic'?'selected':'' ?>>Automatic</option>
                            <option <?= $trans==='Manual'?'selected':'' ?>>Manual</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Max Price / Day</label>
                        <input type="number" name="max_price" class="form-control" placeholder="e.g. 10000"
                               value="<?= $maxPrice < 999999 ? $maxPrice : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sort By</label>
                        <select name="sort" class="form-select">
                            <option value="newest"     <?= $sortBy==='newest'?'selected':'' ?>>Newest First</option>
                            <option value="price_asc"  <?= $sortBy==='price_asc'?'selected':'' ?>>Price: Low → High</option>
                            <option value="price_desc" <?= $sortBy==='price_desc'?'selected':'' ?>>Price: High → Low</option>
                            <option value="name_asc"   <?= $sortBy==='name_asc'?'selected':'' ?>>Name A–Z</option>
                        </select>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn-primary-custom text-center" style="padding:0.6rem">
                            <i class="fas fa-search me-2"></i>Apply Filters
                        </button>
                        <a href="browse_cars.php" class="btn btn-outline-secondary btn-sm rounded-3">
                            <i class="fas fa-times me-1"></i>Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Car Grid -->
        <div class="col-lg-9">
            <?php if (empty($cars)): ?>
            <div class="text-center py-5">
                <div style="font-size:4rem">🔍</div>
                <h4 style="font-family:'Rajdhani',sans-serif;margin:1rem 0 0.5rem">No Cars Found</h4>
                <p class="text-muted">Try adjusting your filters.</p>
                <a href="browse_cars.php" class="btn-primary-custom mt-2" style="display:inline-block">View All Cars</a>
            </div>
            <?php else: ?>
            <div class="row g-4" id="carGrid">
                <?php foreach ($cars as $i => $car): ?>
                <div class="col-md-6 col-xl-4 car-filter-item"
                     data-category="<?= $car['category'] ?>"
                     data-transmission="<?= $car['transmission'] ?>"
                     data-price="<?= $car['price_per_day'] ?>"
                     data-name="<?= strtolower($car['brand'].' '.$car['model']) ?>"
                     data-aos="fade-up" data-aos-delay="<?= ($i % 3) * 80 ?>">
                    <?php
                        $badgeClass = ['Available'=>'badge-available','Rented'=>'badge-rented','Maintenance'=>'badge-maintenance'][$car['status']] ?? 'badge-available';
                        $isAvailable = $car['status'] === 'Available';
                    ?>
                    <div class="car-card h-100" style="<?= $isAvailable ? '' : 'opacity:0.85' ?>">
                        <div style="position:relative">
                            <div class="car-card-img" style="background:linear-gradient(135deg,#1a1a2e,#0f3460)">
                                🚘
                            </div>
                            <span class="car-badge <?= $badgeClass ?>"><?= $car['status'] ?></span>
                            <span style="position:absolute;top:12px;left:12px;background:rgba(0,0,0,0.6);color:#fff;font-size:0.75rem;padding:3px 10px;border-radius:20px">
                                <?= $car['category'] ?>
                            </span>
                        </div>
                        <div class="car-card-body">
                            <div class="car-name"><?= htmlspecialchars($car['brand'].' '.$car['model']) ?></div>
                            <div class="car-category"><?= $car['year'] ?> · <?= $car['color'] ?></div>
                            <div class="car-specs">
                                <span class="spec-tag"><i class="fas fa-cog"></i><?= $car['transmission'] ?></span>
                                <span class="spec-tag"><i class="fas fa-gas-pump"></i><?= $car['fuel_type'] ?></span>
                                <span class="spec-tag"><i class="fas fa-users"></i><?= $car['seats'] ?> Seats</span>
                                <span class="spec-tag"><i class="fas fa-id-card"></i><?= htmlspecialchars($car['license_plate']) ?></span>
                            </div>
                            <?php if ($car['description']): ?>
                            <p style="font-size:0.82rem;color:var(--text-muted);margin:0.75rem 0;line-height:1.5">
                                <?= htmlspecialchars(substr($car['description'], 0, 90)) ?>...
                            </p>
                            <?php endif; ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div class="car-price">
                                    <?= formatPrice($car['price_per_day']) ?>
                                    <span>/day</span>
                                </div>
                                <?php if (!$isAvailable): ?>
                                <button class="btn btn-secondary" disabled style="padding:0.45rem 1.1rem;font-size:0.88rem;border-radius:var(--radius)">
                                    <?= $car['status'] === 'Rented' ? 'Currently Rented' : 'Unavailable' ?>
                                </button>
                                <?php elseif (isLoggedIn()): ?>
                                <a href="book_car.php?id=<?= $car['id'] ?>" class="btn-primary-custom" style="padding:0.45rem 1.1rem;font-size:0.88rem">
                                    Book Now
                                </a>
                                <?php else: ?>
                                <a href="../auth/login.php" class="btn-primary-custom" style="padding:0.45rem 1.1rem;font-size:0.88rem">
                                    Login to Book
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

