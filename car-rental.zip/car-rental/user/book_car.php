<?php
$pageTitle = 'Book Car';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireLogin();

$carId = intval($_GET['id'] ?? 0);
if (!$carId) { setFlash('error', 'Invalid car.'); redirect(SITE_URL.'/user/browse_cars.php'); }

$carStmt = $conn->prepare("SELECT * FROM cars WHERE id = ? AND status = 'Available'");
$carStmt->bind_param("i", $carId);
$carStmt->execute();
$car = $carStmt->get_result()->fetch_assoc();

if (!$car) { setFlash('error', 'Car not available.'); redirect(SITE_URL.'/user/browse_cars.php'); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pickup   = sanitize($_POST['pickup_date']   ?? '');
    $return_d = sanitize($_POST['return_date']    ?? '');
    $location = sanitize($_POST['pickup_location']?? '');
    $notes    = sanitize($_POST['notes']          ?? '');
    $uid      = $_SESSION['user_id'];

    if (empty($pickup) || empty($return_d)) {
        $error = 'Please select pickup and return dates.';
    } elseif ($return_d <= $pickup) {
        $error = 'Return date must be after pickup date.';
    } elseif ($pickup < date('Y-m-d')) {
        $error = 'Pickup date cannot be in the past.';
    } else {
        // Check if car already booked for those dates
        $conflict = $conn->prepare("
            SELECT id FROM bookings
            WHERE car_id = ? AND status NOT IN ('Cancelled','Completed')
            AND NOT (return_date <= ? OR pickup_date >= ?)
        ");
        $conflict->bind_param("iss", $carId, $pickup, $return_d);
        $conflict->execute();
        if ($conflict->get_result()->num_rows > 0) {
            $error = 'This car is already booked for the selected dates. Please choose different dates.';
        } else {
            $days  = (int)((strtotime($return_d) - strtotime($pickup)) / 86400);
            $total = $days * $car['price_per_day'];

            $ins = $conn->prepare("INSERT INTO bookings (user_id,car_id,pickup_date,return_date,pickup_location,total_days,total_price,notes) VALUES (?,?,?,?,?,?,?,?)");
            $ins->bind_param("iisssids", $uid, $carId, $pickup, $return_d, $location, $days, $total, $notes);

            if ($ins->execute()) {
                $bookingId = $conn->insert_id;
                setFlash('success', "Booking #$bookingId confirmed! We'll contact you shortly.");
                redirect(SITE_URL.'/user/my_bookings.php');
            } else {
                $error = 'Booking failed. Please try again.';
            }
        }
    }
}
?>

<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2" style="background:none;padding:0">
                <li class="breadcrumb-item"><a href="browse_cars.php" style="color:rgba(255,255,255,0.6)">Browse Cars</a></li>
                <li class="breadcrumb-item active" style="color:#fff">Book Car</li>
            </ol>
        </nav>
        <h1 style="font-family:'Rajdhani',sans-serif;font-size:2.2rem;margin:0">
            Book: <?= htmlspecialchars($car['brand'].' '.$car['model']) ?>
        </h1>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4">

        <!-- Booking Form -->
        <div class="col-lg-7" data-aos="fade-right">
            <div class="form-card">
                <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.3rem;margin-bottom:1.5rem">
                    <i class="fas fa-calendar-check me-2 text-accent"></i>Booking Details
                </h5>

                <?php if ($error): ?>
                <div class="alert-custom alert-error">
                    <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                </div>
                <?php endif; ?>

                <!-- Hidden price_per_day for JS calculator -->
                <input type="hidden" id="price_per_day" value="<?= $car['price_per_day'] ?>">

                <form method="POST" class="needs-validation" novalidate>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Pickup Date *</label>
                            <input type="date" name="pickup_date" id="pickup_date" class="form-control"
                                   min="<?= date('Y-m-d') ?>"
                                   value="<?= htmlspecialchars($_POST['pickup_date'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Return Date *</label>
                            <input type="date" name="return_date" id="return_date" class="form-control"
                                   min="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                                   value="<?= htmlspecialchars($_POST['return_date'] ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Pickup Location</label>
                            <input type="text" name="pickup_location" class="form-control"
                                   placeholder="e.g. Taxila Cantt, Rawalpindi"
                                   value="<?= htmlspecialchars($_POST['pickup_location'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Additional Notes</label>
                            <textarea name="notes" class="form-control" rows="3"
                                      placeholder="Any special requirements or instructions..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- Price Summary (JS-driven) -->
                    <div id="priceSummary" style="display:none;background:var(--light-bg);border:1.5px solid var(--border);border-radius:var(--radius);padding:1.25rem;margin-top:1.5rem">
                        <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin-bottom:1rem">Price Summary</h6>
                        <div class="d-flex justify-content-between mb-2" style="font-size:0.9rem">
                            <span class="text-muted">Duration</span>
                            <strong id="total_days">—</strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2" style="font-size:0.9rem">
                            <span class="text-muted">Rate</span>
                            <strong><?= formatPrice($car['price_per_day']) ?>/day</strong>
                        </div>
                        <hr style="margin:0.75rem 0">
                        <div class="d-flex justify-content-between">
                            <span style="font-weight:700;font-family:'Rajdhani',sans-serif;font-size:1.1rem">Total</span>
                            <span style="font-family:'Rajdhani',sans-serif;font-size:1.3rem;font-weight:700;color:var(--accent)" id="total_price">—</span>
                        </div>
                    </div>

                    <button type="submit" class="btn-primary-custom w-100 mt-4" style="font-size:1.05rem">
                        <i class="fas fa-check-circle me-2"></i>Confirm Booking
                    </button>
                </form>
            </div>
        </div>

        <!-- Car Details Card -->
        <div class="col-lg-5" data-aos="fade-left">
            <div class="car-card mb-4">
                <div class="car-card-img" style="height:180px;font-size:6rem;background:linear-gradient(135deg,#1a1a2e,#0f3460)">
                    🚘
                </div>
                <div class="car-card-body">
                    <div class="car-name"><?= htmlspecialchars($car['brand'].' '.$car['model']) ?></div>
                    <div class="car-category"><?= $car['category'] ?> · <?= $car['year'] ?></div>
                    <div class="car-specs">
                        <span class="spec-tag"><i class="fas fa-cog"></i><?= $car['transmission'] ?></span>
                        <span class="spec-tag"><i class="fas fa-gas-pump"></i><?= $car['fuel_type'] ?></span>
                        <span class="spec-tag"><i class="fas fa-users"></i><?= $car['seats'] ?> Seats</span>
                        <span class="spec-tag"><i class="fas fa-palette"></i><?= $car['color'] ?></span>
                        <span class="spec-tag"><i class="fas fa-id-card"></i><?= $car['license_plate'] ?></span>
                    </div>
                    <?php if ($car['description']): ?>
                    <p style="font-size:0.88rem;color:var(--text-muted);margin-top:0.75rem;line-height:1.6">
                        <?= htmlspecialchars($car['description']) ?>
                    </p>
                    <?php endif; ?>
                    <div class="car-price mt-2"><?= formatPrice($car['price_per_day']) ?> <span>/day</span></div>
                </div>
            </div>

            <!-- Booking Policy -->
            <div class="form-card">
                <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin-bottom:1rem">
                    <i class="fas fa-info-circle me-2 text-accent"></i>Booking Policy
                </h6>
                <ul class="list-unstyled" style="font-size:0.85rem;color:var(--text-muted);line-height:2">
                    <li><i class="fas fa-check text-success me-2"></i>Free cancellation before pickup</li>
                    <li><i class="fas fa-check text-success me-2"></i>Full insurance included</li>
                    <li><i class="fas fa-check text-success me-2"></i>Fuel not included</li>
                    <li><i class="fas fa-check text-success me-2"></i>Valid CNIC required at pickup</li>
                    <li><i class="fas fa-check text-success me-2"></i>Minimum booking: 1 day</li>
                </ul>
            </div>
        </div>

    </div>
</div>

<script>
// Show price summary when both dates are selected
document.addEventListener('DOMContentLoaded', function() {
    const summary = document.getElementById('priceSummary');
    const pickup  = document.getElementById('pickup_date');
    const ret     = document.getElementById('return_date');

    function check() {
        if (pickup.value && ret.value && ret.value > pickup.value) {
            summary.style.display = 'block';
        } else {
            summary.style.display = 'none';
        }
    }
    pickup.addEventListener('change', check);
    ret.addEventListener('change', check);
});
</script>

<?php require_once '../includes/footer.php'; ?>
