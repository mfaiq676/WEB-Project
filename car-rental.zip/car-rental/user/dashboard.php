<?php
$pageTitle = 'My Dashboard';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireLogin();

$uid = $_SESSION['user_id'];

// Stats
$totalBookings     = $conn->query("SELECT COUNT(*) as c FROM bookings WHERE user_id=$uid")->fetch_assoc()['c'];
$activeBookings    = $conn->query("SELECT COUNT(*) as c FROM bookings WHERE user_id=$uid AND status IN ('Pending','Confirmed','Ongoing')")->fetch_assoc()['c'];
$completedBookings = $conn->query("SELECT COUNT(*) as c FROM bookings WHERE user_id=$uid AND status='Completed'")->fetch_assoc()['c'];
$totalSpent        = $conn->query("SELECT COALESCE(SUM(total_price),0) as s FROM bookings WHERE user_id=$uid AND payment_status='Paid'")->fetch_assoc()['s'];

// Recent bookings
$recent = $conn->query("
    SELECT b.*, c.brand, c.model, c.category, c.price_per_day
    FROM bookings b
    JOIN cars c ON b.car_id = c.id
    WHERE b.user_id = $uid
    ORDER BY b.created_at DESC
    LIMIT 5
");

// User info
$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
?>

<div class="page-header">
    <div class="container">
        <h1 style="font-family:'Rajdhani',sans-serif;font-size:2.2rem;margin:0">
            Welcome back, <?= htmlspecialchars(explode(' ', $user['full_name'])[0]) ?> 👋
        </h1>
        <p style="color:rgba(255,255,255,0.7);margin:0.25rem 0 0">Here's your rental activity overview</p>
    </div>
</div>

<div class="container pb-5">

    <!-- Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-3 col-sm-6" data-aos="fade-up">
            <div class="stat-card blue">
                <div class="stat-icon">📋</div>
                <div class="stat-val"><?= $totalBookings ?></div>
                <div class="stat-lbl">Total Bookings</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="80">
            <div class="stat-card amber">
                <div class="stat-icon">🚗</div>
                <div class="stat-val"><?= $activeBookings ?></div>
                <div class="stat-lbl">Active Rentals</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="160">
            <div class="stat-card green">
                <div class="stat-icon">✅</div>
                <div class="stat-val"><?= $completedBookings ?></div>
                <div class="stat-lbl">Completed</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="240">
            <div class="stat-card red">
                <div class="stat-icon">💰</div>
                <div class="stat-val" style="font-size:1.5rem"><?= formatPrice($totalSpent) ?></div>
                <div class="stat-lbl">Total Spent</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Recent Bookings -->
        <div class="col-lg-8" data-aos="fade-up">
            <div class="table-custom">
                <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                    <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.2rem;margin:0">Recent Bookings</h5>
                    <a href="my_bookings.php" style="color:var(--accent);font-size:0.9rem;font-weight:600">View All →</a>
                </div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th class="px-3 py-3" style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">#</th>
                                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Car</th>
                                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Dates</th>
                                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Amount</th>
                                <th style="background:var(--primary);color:rgba(255,255,255,0.85);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recent->num_rows > 0):
                                while ($b = $recent->fetch_assoc()): ?>
                            <tr>
                                <td class="px-3">#<?= $b['id'] ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($b['brand'].' '.$b['model']) ?></strong><br>
                                    <small class="text-muted"><?= $b['category'] ?></small>
                                </td>
                                <td>
                                    <small><?= date('d M', strtotime($b['pickup_date'])) ?> → <?= date('d M Y', strtotime($b['return_date'])) ?></small><br>
                                    <small class="text-muted"><?= $b['total_days'] ?> day(s)</small>
                                </td>
                                <td><strong><?= formatPrice($b['total_price']) ?></strong></td>
                                <td><span class="status-badge status-<?= strtolower($b['status']) ?>"><?= $b['status'] ?></span></td>
                            </tr>
                            <?php endwhile;
                            else: ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">No bookings yet. <a href="browse_cars.php" style="color:var(--accent)">Browse cars →</a></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Profile Card -->
        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="form-card mb-4">
                <div class="text-center mb-3">
                    <div style="width:70px;height:70px;background:linear-gradient(135deg,var(--accent),#c1121f);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;margin:0 auto 0.75rem">
                        <?= strtoupper(substr($user['full_name'],0,1)) ?>
                    </div>
                    <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.3rem;margin-bottom:0"><?= htmlspecialchars($user['full_name']) ?></h5>
                    <small class="text-muted"><?= htmlspecialchars($user['email']) ?></small>
                </div>
                <hr>
                <ul class="list-unstyled" style="font-size:0.88rem">
                    <li class="d-flex gap-2 mb-2"><i class="fas fa-phone text-accent mt-1"></i><span><?= $user['phone'] ?: 'Not provided' ?></span></li>
                    <li class="d-flex gap-2 mb-2"><i class="fas fa-map-marker-alt text-accent mt-1"></i><span><?= $user['address'] ?: 'Not provided' ?></span></li>
                    <li class="d-flex gap-2"><i class="fas fa-calendar text-accent mt-1"></i><span>Joined <?= date('M Y', strtotime($user['created_at'])) ?></span></li>
                </ul>
            </div>

            <!-- Quick Actions -->
            <div class="form-card">
                <h6 style="font-family:'Rajdhani',sans-serif;font-size:1.1rem;margin-bottom:1rem">Quick Actions</h6>
                <div class="d-grid gap-2">
                    <a href="browse_cars.php" class="btn-primary-custom text-center" style="padding:0.65rem">
                        <i class="fas fa-car me-2"></i>Rent a Car
                    </a>
                    <a href="my_bookings.php" class="btn btn-outline-secondary btn-sm rounded-3 py-2">
                        <i class="fas fa-list me-2"></i>All My Bookings
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
