<?php
$pageTitle = 'My Bookings';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireLogin();

$uid = $_SESSION['user_id'];

// Handle cancel
if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $bid = intval($_GET['cancel']);
    // Verify ownership and status
    $check = $conn->prepare("SELECT id, status FROM bookings WHERE id=? AND user_id=?");
    $check->bind_param("ii", $bid, $uid);
    $check->execute();
    $booking = $check->get_result()->fetch_assoc();

    if ($booking && in_array($booking['status'], ['Pending', 'Confirmed'])) {
        $conn->query("UPDATE bookings SET status='Cancelled' WHERE id=$bid");
        setFlash('success', "Booking #$bid has been cancelled.");
    } else {
        setFlash('error', 'Cannot cancel this booking.');
    }
    redirect(SITE_URL.'/user/my_bookings.php');
}

// Filter
$statusFilter = sanitize($_GET['status'] ?? '');
$where        = "b.user_id = $uid";
if ($statusFilter) $where .= " AND b.status = '$statusFilter'";

$bookings = $conn->query("
    SELECT b.*, c.brand, c.model, c.category, c.color, c.transmission, c.seats, c.fuel_type
    FROM bookings b
    JOIN cars c ON b.car_id = c.id
    WHERE $where
    ORDER BY b.created_at DESC
");
?>

<div class="page-header">
    <div class="container">
        <h1 style="font-family:'Rajdhani',sans-serif;font-size:2.2rem;margin:0">My Bookings</h1>
        <p style="color:rgba(255,255,255,0.7);margin:0.25rem 0 0">Track and manage all your car rentals</p>
    </div>
</div>

<div class="container pb-5">

    <!-- Filter Tabs -->
    <div class="d-flex gap-2 flex-wrap mb-4" data-aos="fade-up">
        <?php
        $statuses = ['All','Pending','Confirmed','Ongoing','Completed','Cancelled'];
        foreach ($statuses as $s):
            $val    = $s === 'All' ? '' : $s;
            $active = $statusFilter === $val ? 'style="background:var(--accent);color:#fff;border-color:var(--accent)"' : '';
        ?>
        <a href="?status=<?= $val ?>"
           class="btn btn-outline-secondary btn-sm rounded-pill px-3 py-2" <?= $active ?>>
            <?= $s ?>
        </a>
        <?php endforeach; ?>

        <a href="browse_cars.php" class="btn-primary-custom ms-auto" style="padding:0.4rem 1.2rem;font-size:0.9rem">
            <i class="fas fa-plus me-1"></i>New Booking
        </a>
    </div>

    <?php if ($bookings->num_rows === 0): ?>
    <div class="text-center py-5" data-aos="fade-up">
        <div style="font-size:4rem">📭</div>
        <h4 style="font-family:'Rajdhani',sans-serif;margin:1rem 0 0.5rem">No Bookings Found</h4>
        <p class="text-muted">
            <?= $statusFilter ? "No $statusFilter bookings." : "You haven't made any bookings yet." ?>
        </p>
        <a href="browse_cars.php" class="btn-primary-custom mt-2" style="display:inline-block">Browse Cars</a>
    </div>

    <?php else: ?>
    <div class="row g-4">
        <?php $i = 0; while ($b = $bookings->fetch_assoc()): $i++; ?>
        <div class="col-12" data-aos="fade-up" data-aos-delay="<?= ($i % 5) * 60 ?>">
            <div class="car-card" style="border-radius:var(--radius)">
                <div class="row g-0">
                    <!-- Car Emoji Visual -->
                    <div class="col-md-2 d-flex align-items-center justify-content-center"
                         style="background:linear-gradient(135deg,#1a1a2e,#0f3460);min-height:140px;border-radius:var(--radius) 0 0 var(--radius);font-size:4rem">
                        🚘
                    </div>

                    <!-- Booking Info -->
                    <div class="col-md-7 p-3">
                        <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-2">
                            <div>
                                <span style="font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px">Booking #<?= $b['id'] ?></span>
                                <h5 style="font-family:'Rajdhani',sans-serif;font-size:1.3rem;margin:0">
                                    <?= htmlspecialchars($b['brand'].' '.$b['model']) ?>
                                </h5>
                                <small class="text-muted"><?= $b['category'] ?> · <?= $b['color'] ?></small>
                            </div>
                            <span class="status-badge status-<?= strtolower($b['status']) ?>"><?= $b['status'] ?></span>
                        </div>

                        <div class="row g-2 mt-1" style="font-size:0.88rem">
                            <div class="col-sm-4">
                                <i class="fas fa-calendar-alt text-accent me-1"></i>
                                <strong>Pickup:</strong><br>
                                <span class="ms-3 text-muted"><?= date('d M Y', strtotime($b['pickup_date'])) ?></span>
                            </div>
                            <div class="col-sm-4">
                                <i class="fas fa-calendar-check text-accent me-1"></i>
                                <strong>Return:</strong><br>
                                <span class="ms-3 text-muted"><?= date('d M Y', strtotime($b['return_date'])) ?></span>
                            </div>
                            <div class="col-sm-4">
                                <i class="fas fa-clock text-accent me-1"></i>
                                <strong>Duration:</strong><br>
                                <span class="ms-3 text-muted"><?= $b['total_days'] ?> day(s)</span>
                            </div>
                            <?php if ($b['pickup_location']): ?>
                            <div class="col-12 mt-1">
                                <i class="fas fa-map-marker-alt text-accent me-1"></i>
                                <strong>Location:</strong>
                                <span class="text-muted ms-1"><?= htmlspecialchars($b['pickup_location']) ?></span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="car-specs mt-2">
                            <span class="spec-tag"><i class="fas fa-cog"></i><?= $b['transmission'] ?></span>
                            <span class="spec-tag"><i class="fas fa-gas-pump"></i><?= $b['fuel_type'] ?></span>
                            <span class="spec-tag"><i class="fas fa-users"></i><?= $b['seats'] ?> Seats</span>
                        </div>
                    </div>

                    <!-- Price + Actions -->
                    <div class="col-md-3 p-3 d-flex flex-column justify-content-between"
                         style="border-left:1px solid var(--border)">
                        <div>
                            <div style="font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px">Total Amount</div>
                            <div class="car-price"><?= formatPrice($b['total_price']) ?></div>
                            <span class="status-badge mt-1 d-inline-block <?= $b['payment_status']==='Paid' ? 'status-completed' : 'status-pending' ?>">
                                <?= $b['payment_status'] ?>
                            </span>
                        </div>
                        <div>
                            <small class="text-muted d-block mb-2">
                                Booked: <?= date('d M Y', strtotime($b['created_at'])) ?>
                            </small>
                            <?php if (in_array($b['status'], ['Pending','Confirmed'])): ?>
                            <a href="?cancel=<?= $b['id'] ?>"
                               class="btn btn-outline-danger btn-sm w-100 rounded-3 btn-delete">
                                <i class="fas fa-times me-1"></i>Cancel Booking
                            </a>
                            <?php elseif ($b['status'] === 'Completed'): ?>
                            <a href="browse_cars.php" class="btn btn-outline-secondary btn-sm w-100 rounded-3">
                                <i class="fas fa-redo me-1"></i>Book Again
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
